package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class PopMusicActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_name_list);

        //Creates the customized toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitleTextColor(Color.WHITE);
        myToolbar.setSubtitle("List of pop songs");

        ActionBar myActionbar = getSupportActionBar();
        myActionbar.setDisplayHomeAsUpEnabled(true);
        //Creates an array of pop music songs with the states title and artist

        ArrayList<Song> popMusicLibrary = new ArrayList<Song>();

        popMusicLibrary.add(new Song("Meant To Be", "Bebe Rexha & Florida Georgia Line"));
        popMusicLibrary.add(new Song("Havana", "Camila Cabello Featuring Young Thug"));
        popMusicLibrary.add(new Song("Tell Me You Love Me", "Demi Lovato"));
        popMusicLibrary.add(new Song("Beautiful Trauma", "P!nk"));
        popMusicLibrary.add(new Song("New Rules", "Dua Lipa"));
        popMusicLibrary.add(new Song("Lights Down Low", "MAX Featuring gnash"));
        popMusicLibrary.add(new Song("I Like Me Better", "Lauv"));
        popMusicLibrary.add(new Song("Mine", "Bazzi"));
        popMusicLibrary.add(new Song("Beg", "Jack & Jack"));
        popMusicLibrary.add(new Song("On The Loose", "Niall Horan"));

        SongAdapter adapter = new SongAdapter(this, popMusicLibrary);

        ListView listView = (ListView) findViewById(R.id.list_view);

        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.go_to_pop) {
            Intent nowPlayingIntent = new Intent(this, PopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_rock) {
            Intent nowPlayingIntent = new Intent(this, RockMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_hip_hop) {
            Intent nowPlayingIntent = new Intent(this, HipHopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        return super.onOptionsItemSelected(item);
    }

}

