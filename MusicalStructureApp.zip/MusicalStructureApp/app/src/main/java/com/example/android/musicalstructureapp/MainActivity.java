package com.example.android.musicalstructureapp;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        // Finds ButtonView that shows the pop music category
        Button popmusic = (Button) findViewById(R.id.pop);

        // Set a click listener on that View
        popmusic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //Creat a new intent to open the pop music libaray
                Intent popmusicintent = new Intent(MainActivity.this, PopMusicActivity.class);
                startActivity(popmusicintent);
                Toast.makeText(view.getContext(), "Welcome, you opened the list of pop music.", Toast.LENGTH_LONG).show();
            }
        });

        // Finds ButtonView that shows the rock music category
        Button rockmusic = (Button) findViewById(R.id.rock);

        // Set a click listener on that View
        rockmusic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //Creat a new intent to open the rock music libaray
                Intent rockmusicintent = new Intent(MainActivity.this, RockMusicActivity.class);
                startActivity(rockmusicintent);
                Toast.makeText(view.getContext(), "Welcome, you opened the list of rock music.", Toast.LENGTH_LONG).show();
            }
        });

        // Finds ButtonView that shows the hip hop music category
        Button hiphopmusic = (Button) findViewById(R.id.hip_hop);

        // Set a click listener on that View
        hiphopmusic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //Creat a new intent to open the pop music libaray
                Intent hiphopmusicintent = new Intent(MainActivity.this, HipHopMusicActivity.class);
                startActivity(hiphopmusicintent);
                Toast.makeText(view.getContext(), "Welcome, you opened the list of hip hop music.", Toast.LENGTH_LONG).show();
            }
        });
    }
}




