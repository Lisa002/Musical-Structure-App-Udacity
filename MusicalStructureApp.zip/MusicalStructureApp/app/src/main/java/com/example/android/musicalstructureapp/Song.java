package com.example.android.musicalstructureapp;

/**
 * Created by Jaina on 12.03.2018.
 */

public class Song {

    private String title;

    private String artistName;

    /**
     * Create a new Song object.
     */

    public Song(String title, String artistName) {
        this.title = title;
        this.artistName = artistName;
    }

    /**
     * get the songTitle
     */

    public String getTitle() {
        return title;
    }

    /**
     * get the artistName
     */
    public String getArtistName() {
        return artistName;
    }

}








