package com.example.android.musicalstructureapp;


import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class NowPlayingActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);
        //Creates the customized toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitleTextColor(Color.WHITE);
        myToolbar.setSubtitle("Show the now playing song.");

        ActionBar myActionbar = getSupportActionBar();
        myActionbar.setDisplayHomeAsUpEnabled(true);

        //saves the title and artist
        Bundle b = getIntent().getExtras();
        String title = b.getString("title");
        String artist = b.getString("artist");

        //Finds the TextView for the now playing title
        TextView titleView = (TextView) findViewById(R.id.now_playing_title_text_view);
        //sets the title in the view when the now playing button is pushed
        titleView.setText(title);

        //Finds the TextView for the now playing artist
        TextView artistView = (TextView) findViewById(R.id.now_playing_artist_text_view);
        //sets the artist in the view when the now playing button is pushed
        artistView.setText(artist);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.go_to_pop) {
            Intent nowPlayingIntent = new Intent(this, PopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_rock) {
            Intent nowPlayingIntent = new Intent(this, RockMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_hip_hop) {
            Intent nowPlayingIntent = new Intent(this, HipHopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}