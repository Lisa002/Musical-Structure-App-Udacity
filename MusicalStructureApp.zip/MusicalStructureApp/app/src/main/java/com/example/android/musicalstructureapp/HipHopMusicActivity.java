package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;

public class HipHopMusicActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_name_list);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitleTextColor(Color.WHITE);
        myToolbar.setSubtitle("List of Hip Hop songs");

        ActionBar myActionbar = getSupportActionBar();
        myActionbar.setDisplayHomeAsUpEnabled(true);

        //Creates an array of hip hop music songs with the states title and artist

        ArrayList<Song> hiphopMusicLibrary = new ArrayList<Song>();

        hiphopMusicLibrary.add(new Song("God's Plan", "Drake"));
        hiphopMusicLibrary.add(new Song("Psycho", "Post Malone Featuring Ty Dolla $ign"));
        hiphopMusicLibrary.add(new Song("Pray For Me", "The Weeknd & Kendrick Lamar "));
        hiphopMusicLibrary.add(new Song("All The Stars", "Kendrick Lamar & SZA"));
        hiphopMusicLibrary.add(new Song("Bartier Cardi", "Cardi B Featuring 21 Savage"));
        hiphopMusicLibrary.add(new Song("Ric Flair Drip", "Offset & Metro Boomin"));
        hiphopMusicLibrary.add(new Song("Sky Walker", "Miguel Featuring Travis Scott"));
        hiphopMusicLibrary.add(new Song("Plain Jane", " A$AP Ferg Featuring Nicki Minaj"));
        hiphopMusicLibrary.add(new Song("New Freezer", " Rich The Kid Featuring Kendrick Lamar"));
        hiphopMusicLibrary.add(new Song("River", " Eminem Featuring Ed Sheeran"));

        SongAdapter adapter = new SongAdapter(this, hiphopMusicLibrary);

        ListView listView = (ListView) findViewById(R.id.list_view);

        listView.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.go_to_pop) {
            Intent nowPlayingIntent = new Intent(this, PopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_rock) {
            Intent nowPlayingIntent = new Intent(this, RockMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_hip_hop) {
            Intent nowPlayingIntent = new Intent(this, HipHopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }

        return super.onOptionsItemSelected(item);
    }

}



