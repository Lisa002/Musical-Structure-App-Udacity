package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class RockMusicActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_name_list);

        //Creates the customized toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitleTextColor(Color.WHITE);
        myToolbar.setSubtitle("List of rock songs");

        ActionBar myActionbar = getSupportActionBar();
        myActionbar.setDisplayHomeAsUpEnabled(true);
        //Creates an array of rock music songs with the states title and artist

        ArrayList<Song> rockMusicLibrary = new ArrayList<Song>();

        rockMusicLibrary.add(new Song("Thunder", "Imagine Dragons"));
        rockMusicLibrary.add(new Song("Run For Cover", "The Killers"));
        rockMusicLibrary.add(new Song("Happy Hour", "Weezer "));
        rockMusicLibrary.add(new Song("World Gone Mad", "Bastille"));
        rockMusicLibrary.add(new Song("One Foot", "WALK THE MOON"));
        rockMusicLibrary.add(new Song("No Roots", "Alice Merton"));
        rockMusicLibrary.add(new Song("Sit Next To Me", "Foster The People"));
        rockMusicLibrary.add(new Song("MineZombie", "Bad Wolves"));
        rockMusicLibrary.add(new Song("Walk On Water", "Thirty Seconds To Mars"));
        rockMusicLibrary.add(new Song("Gone Away", "Five Finger Death Punch"));

        SongAdapter adapter = new SongAdapter(this, rockMusicLibrary);

        ListView listView = (ListView) findViewById(R.id.list_view);

        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.go_to_pop) {
            Intent nowPlayingIntent = new Intent(this, PopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_rock) {
            Intent nowPlayingIntent = new Intent(this, RockMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }
        if (id == R.id.go_to_hip_hop) {
            Intent nowPlayingIntent = new Intent(this, HipHopMusicActivity.class);
            this.startActivity(nowPlayingIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}

